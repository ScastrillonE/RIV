
def handler(event, context):
    print("HOLA a todos")